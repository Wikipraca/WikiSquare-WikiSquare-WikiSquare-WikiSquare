jQuery(document).ready(function($){
    $('.ga_dash_style').wpColorPicker();
});